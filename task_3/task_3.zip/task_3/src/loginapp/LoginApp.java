
package loginapp;

/**
 *
 * @author ritesh
 */
public class LoginApp {

    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
